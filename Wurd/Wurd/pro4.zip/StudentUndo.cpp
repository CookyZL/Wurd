#include "StudentUndo.h"
#include <stack>

Undo* createUndo()
{
	return new StudentUndo;
}

StudentUndo::ID::ID(char character, Undo::Action id, int row, int col) {
	cUndo = character;
	m_id = id;
	m_row = row;
	m_col = col;
}

//This method must run in O(1) time in the average case, understanding that it may
//increase to O(current line length where the operation occurred) infrequently.
//but my time complexity is o(1), does this violates??
void StudentUndo::submit(const Action action, int row, int col, char ch) {
	m_undoStack.push(ID(ch, action, row, col));
}

//This method must run in O(1) time in the average case, understanding that it may
//increase to O(length of deleted characters that need to be restored) for restoration cases.
StudentUndo::Action StudentUndo::get(int &row, int &col, int& count, std::string& text) {
	ID* temp;
	if (m_undoStack.empty()) {
		//If the undo stack was empty when this
			//method was called
		return Undo::Action::ERROR;
	}
	temp = &m_undoStack.top();
	m_undoStack.pop();
	count = 0;
	row = 0;
	col = 0;
	text = "";
	//check if the undo submit is insert
	if (temp->m_id == Undo::Action::INSERT) {
		//change the parameters
			count++;
		row = temp->m_row;
		col = temp->m_col;
		//if the next one the action is still insert and the col is the next of the previous one
		//continue change the parameter
		while (!(m_undoStack.empty())) {
			if ((m_undoStack.top().m_id == Undo::Action::INSERT && m_undoStack.top().m_row == row &&m_undoStack.top().m_col + 1 == col&& temp->cUndo != ' ')){
				temp = &m_undoStack.top();
				m_undoStack.pop();
					count++;
					col--;
				if (temp->cUndo == ' ') {
					return Undo::Action::DELETE;
				}
			}
			else {
				return Undo::Action::DELETE;
			}
		}
		return Undo::Action::DELETE;
	}
 //if the action is delete
	if (temp->m_id == Undo::Action::DELETE) {
		//change the parameters
		text = text + temp->cUndo;
		row = temp->m_row;
		col = temp->m_col;
		int fCol = col;
		count++;
		//if the action is also delete and the col is in the past of the previous one
		while (!m_undoStack.empty() && m_undoStack.top().m_id == Undo::Action::DELETE && m_undoStack.top().m_row == row && m_undoStack.top().m_col == col +1) {
			//change the parameters
			temp = &m_undoStack.top();
			m_undoStack.pop();
			text = text + temp->cUndo;
			col++;
		}
		col = fCol;
		return Undo::Action::INSERT;
	}
	//if the action is to split the line
	if (temp->m_id == Undo::Action::SPLIT) {
		//change the parameters
		row = temp->m_row;
		col = temp->m_col;
		count++;
		return Undo::Action::JOIN;
	}

	//if the action is to join the line
	if (temp->m_id == Undo::Action::JOIN) {
	//change the parameter
		count++;
		row = temp->m_row;
		col = temp->m_col;
		return Undo::Action::SPLIT;

	}

	return Action::ERROR;
}

void StudentUndo::clear() {
	//clear all elements in a stack
	for (int i = 0; i < m_undoStack.size(); i++) {
		m_undoStack.pop();
	}
}
